<link rel="stylesheet" href="bootstrap.min.css">
<form action="" method="post" enctype="multipart/form-data" class="modal-dialog alert alert-danger text-center">
    <h1>Import bank statements excel to Tally</h1>
    Upload Excel: <input type="file" name="file" required accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" /><br />
    Bank Name:<input name="bank" required placeholder="as it is Tally" /><br />
    <input type="submit" name="submit" value="Submit">
</form>
<ul>
<li><mark>Befor click "Submit" button read this</mark></li>
<li>Run Tally First, Then open Company</li>
<li>Set period in Tally for bank statements insertion</li>
<li>Keep in mind date format as DD-MM-YYYY</li>
<li>Number places after decimal should be 2 at Tally</li>
<li>Download Excel format <a href="excel/bank_statement.xls">here</a>. Fill excel with data and import</li>
<li>Write ledger name as it is in Tally in excel ledger column and specify under group</li>
<li>If ledger exist in Tally then it will ignore creation otherwise it will create new ledger with under group provided.</li>
<li>If data not imported then manually import xml file using Tally Import voucher functionality, Copy generated xml path from here <span class="text-danger"><?php echo realpath("xml.xml"); ?></span></li>
</ul>
<?php
if(isset($_POST['submit'])){
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('post_max_size', '1000M'); 
ini_set('upload_max_filesize', '1000M');
$fo=fopen("xml.xml", "w");
    fwrite($fo, "");
    fclose($fo);
$temp = explode(".", $_FILES["file"]["name"]);
$newfilename = 'bank_statement.'.end($temp);
$allowed = array("xls","xlsx", 'application/vnd.ms-excel');
if(!in_array($_FILES["file"]["type"], $allowed)){
    echo "<script>alert('Only excel file allowed.'); </script>";
    exit();
}
if(file_exists("bank_statement.xls")){
    unlink("bank_statement.xls");
}
if(file_exists("bank_statement.xlsx")){
    unlink("bank_statement.xlsx");
}
move_uploaded_file($_FILES["file"]["tmp_name"], $newfilename);
  include 'excel_reader.php';     
  $excel = new PhpExcelReader;
  $excel->read('bank_statement.xls');
  function sheetData($sheet) {
    //It is presumed that the 1st line in the Excel sheet is the header. Hence, we read the data from row 2 onwards
    $x = 2;
    $arr=array();
    while($x <= $sheet['numRows']) {
      $y = 1;
      while($y <= $sheet['numCols']) {
        $cell = isset($sheet['cells'][$x][$y]) ? $sheet['cells'][$x][$y] : '';
        if ($y==1) {
          //Column A of XLS
          $arr[$x-2]["DATE"]= trim($cell);
        }
        if ($y==2) {
          //Column B of XLS
          $arr[$x-2]["NARRATION"]= trim($cell);
        }
        if ($y==3) {
          //Column C of XLS
          $arr[$x-2]["WITHDRAW"]= trim($cell);
        }
        if ($y==4) {
          //Column D of XLS
          $arr[$x-2]["DEPOSIT"]= trim($cell);
        }
        if ($y==5) {
          //Column E of XLS
          $arr[$x-2]["VCH. TYPE"]= trim($cell);
        }
        if ($y==6) {
          //Column F of XLS
          $arr[$x-2]["LEDGER"]= trim($cell);
        }
        if ($y==7) {
          //Column G of XLS
          $arr[$x-2]["UNDER"]= trim($cell);
        }
        if ($y==8) {
          //Column H of XLS
          $arr[$x-2]["CHEQUE NO."]= trim($cell);
        }
        $y++;
      } // end of inner while loop 
      $x++;
    }
    $fo=fopen("bank.json", "w");
    fwrite($fo, json_encode($arr));
    fclose($fo);
  } 
  $excel_data=sheetData($excel->sheets[0]);
  echo "<pre>";
  print_r($excel_data);
$gf=file_get_contents("bank.json");
$jf=json_decode($gf,true);
$bank=$_POST['bank'];
foreach ($jf as $key => $value) {
	$date=trim($jf[$key]["DATE"]);
    $ledger=trim($jf[$key]["LEDGER"]);
    $vchtype=trim($jf[$key]["VCH. TYPE"]);
    $chequeno=trim($jf[$key]["CHEQUE NO."]);
    $narration=trim($jf[$key]["NARRATION"]);
    $withdraw=trim($jf[$key]["WITHDRAW"]);
    $deposit=trim($jf[$key]["DEPOSIT"]);
    $under=trim($jf[$key]["UNDER"]);


$header = '<ENVELOPE>' .
      '<HEADER>' .
      '<TALLYREQUEST>Import Data</TALLYREQUEST>' .
      '</HEADER>' .
      '<BODY>' .
      '<IMPORTDATA>' .
      '<REQUESTDESC>' .
      '<REPORTNAME>All Masters</REPORTNAME>' .
      '</REQUESTDESC>' .
      '<REQUESTDATA>';
      $header .= "<TALLYMESSAGE xmlns:UDF=\"TallyUDF\">";
      $header .= "<LEDGER NAME='$ledger'><NAME>$ledger</NAME>";
      $header .= "<PARENT>$under</PARENT></LEDGER>";
      $header .= "</TALLYMESSAGE>";
    $header .= '</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:9000/');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $header ); // XML data
  $response = curl_exec ($ch);
  curl_close($ch);

    $date=explode("-", $date);
    $date=$date[2].$date[1].$date[0];
	if(!empty($jf[$key]["CHEQUE NO."])){
		$narration=$narration." CHEQUE NO: ".$jf[$key]["CHEQUE NO."];
	}else{
		$narration=$narration;
	}
    
    if($vchtype=="Payment"){
        include("payment.php");
    }
    if($vchtype=="Receipt"){
        include("receipt.php");
    }
    if($vchtype=="Contra" && empty($withdraw)){
        include("contraDeposit.php");
    }
    if($vchtype=="Contra" && empty($deposit)){
        include("contraWithdraw.php");
    }   
    $fo=fopen("xml.xml", "a");
    fwrite($fo, $requestXML);
    fclose($fo);
        $server = 'http://localhost:9000';
        $headers = array( "Content-type: text/xml" ,"Content-length: ".strlen($requestXML) ,"Connection: close" );     
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $server);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 100);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestXML);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_exec($ch);
        if(curl_errno($ch)){
            echo $key.". <b style='color:red;'>Not inserted. Error!.</b><br>";
        }else{
            echo $key.". <b style='color:green;'>Data Successfully Inserted.</b><br>";
            curl_close($ch);
        }
}
}
?>